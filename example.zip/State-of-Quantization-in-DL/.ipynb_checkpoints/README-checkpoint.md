# State-of-Quantization-in-DL
State of Quantization Schemes in DeepLearning
