from .sawb import sawb
from .dorefa import dorefa_weight
from .lsq import lsq_weight
from .mimax import minmax_weight