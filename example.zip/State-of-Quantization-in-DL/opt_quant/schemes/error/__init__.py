from .fixed import fixed
from .absmax import absmax
from .adaptive import adaptive