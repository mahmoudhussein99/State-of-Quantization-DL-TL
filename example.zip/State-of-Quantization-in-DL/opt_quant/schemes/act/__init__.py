from .pact import pact
from .dorefa import dorefa_act
from .lsq import lsq_act
from .minmax import minmax_act
