from .schemes import *
from .utils import *

# if torch.cuda.is_available():
#     from floatxTensor_gpu import makeTensor_cuda as ieee_quant
# else:
#     from floatxTensor import makeTensor as ieee_quant

